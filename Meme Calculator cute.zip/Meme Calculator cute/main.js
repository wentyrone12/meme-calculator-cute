const display = document.getElementById("display");
const sound = document.getElementById("sound");

let heartInterval;

// calculator functions (safe kahit meme calculator)
function appendValue(val) {
    display.value += val;
}

function clearDisplay() {
    display.value = "";
    clearInterval(heartInterval);
    sound.pause();
}

function deleteLast() {
    display.value = display.value.slice(0, -1);
}

// = BUTTON ACTION
function showResult() {
    const message = "I MISS YOU BABY KO🥺🥺";
    display.value = "";

    // play music
    sound.currentTime = 53;
    sound.play();

    // start floating hearts LOOP
    clearInterval(heartInterval);
    heartInterval = setInterval(createHeart, 300);

    // typing animation
    let i = 0;
    function type() {
        if (i < message.length) {
            display.value += message.charAt(i);
            i++;
            setTimeout(type, 120);
        }
    }
    type();
}

// floating hearts function
function createHeart() {
    const heart = document.createElement("div");
    heart.innerText = randomEmoji();
    heart.style.position = "fixed";
    heart.style.left = Math.random() * 100 + "vw";
    heart.style.bottom = "-20px";
    heart.style.fontSize = (Math.random() * 20 + 16) + "px";
    heart.style.pointerEvents = "none";
    heart.style.animation = "floatUp 4s linear forwards";

    document.getElementById("hearts-container").appendChild(heart);

    setTimeout(() => {
        heart.remove();
    }, 4000);
}

// random emoji
function randomEmoji() {
    const emojis = ["❤️", "💔", "🤗", "🥺", "💘"];
    return emojis[Math.floor(Math.random() * emojis.length)];
}

// inject animation (no CSS edit needed)
const style = document.createElement("style");
style.innerHTML = `
@keyframes floatUp {
    from {
        transform: translateY(0) scale(1);
        opacity: 1;
    }
    to {
        transform: translateY(-110vh) scale(1.5);
        opacity: 0;
    }
}
`;
document.head.appendChild(style);
