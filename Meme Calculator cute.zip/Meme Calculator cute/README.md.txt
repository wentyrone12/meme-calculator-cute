# 🧮 Meme Calculator (Cute Edition)

A fun, cute, and aesthetic **Meme Calculator** built using **HTML, CSS, and JavaScript**.  
This project combines a fully functional calculator with a playful meme-style design and sound effects.

Perfect for practice, portfolio showcase, or just for fun 😄💖

---

## ✨ Features

- ✅ Fully functional calculator  
- 🎨 Cute & aesthetic UI design  
- 🌸 Pink gradient & background image  
- 🔊 Sound effect support  
- 📱 Mobile-friendly layout  
- 😂 Meme-inspired vibe

---

## 🛠 Technologies Used

- **HTML5** – Structure  
- **CSS3** – Styling & design  
- **JavaScript** – Calculator logic & interactivity  

---

## 📂 Project Structure

